---
name: office-cad
description: |
  Room standards and layout rules for office, corporate, coworking, and
  commercial workspace layouts — office, corporate office, coworking space,
  IT office, tech park, business center, startup office, call center,
  open plan office, cubicle layout, executive suite, boardroom, co-working,
  hot desk, shared workspace, commercial office, BPO floor.
  ALWAYS use this skill for any office or corporate workspace design.
version: "1.0"
composable_with:
  - cad-core
---

# Office Layout Skill

Office layouts optimize for productivity, collaboration, and visitor flow.
Reception is the gateway, open workspaces dominate the floorplate, private
cabins line the perimeter for window access, and service areas (pantry,
restrooms, server room) are clustered away from work zones.

---

## REFERENCES TO LOAD

- **Always load:** `references/room_standards.md` — minimum sizes for all office zones
- **Load for worked example:** `references/example_layout.json` — complete office floor

---

## DOMAIN-SPECIFIC RULES

**RULE O1 — Reception first.**
Reception MUST be at the main entrance — the first zone visitors see.

**RULE O2 — Open workspace dominance.**
Open workspace should be the largest zone, centrally placed. It may have wide
openings (1500mm+) instead of traditional doors.

**RULE O3 — Perimeter cabins.**
Private cabins and manager cabins should be along the perimeter for window access.

**RULE O4 — Conference near reception.**
Conference and meeting rooms MUST be near reception for visitor access without
passing through work areas.

**RULE O5 — Server room isolation.**
Server room MUST be in the interior (no windows), with restricted access door
and climate control space. It must NOT be adjacent to wet areas.

**RULE O6 — Restroom buffer.**
Restrooms MUST NOT open directly into workspace areas. Use a corridor buffer.

**RULE O7 — Fire safety.**
Fire exits must be reachable from all zones within 30m travel distance.

**RULE O8 — Corridor width.**
Corridors minimum 1500mm wide connecting all zones.

---

## UNKNOWN ROOM HANDLING

For unlisted office zones (e.g., "phone booth", "innovation lab"):
- Phone booth: 1500×1500mm
- Innovation lab: similar to conference room (5000×6000)
- Set `estimated: true`, add to `flagged_estimated_rooms`

---

## CODE COMPLIANCE REFERENCES

**BOMA (ANSI/BOMA Z65.1-2017):**
- Report Usable Area (room footprint) vs Rentable Area (usable + proportional common area)
- Common Area Factor = Building Common Area / Total Usable Area. Typically 1.10-1.20.
- Add "area_type": "usable" to each room. Note: Rentable = Usable × (1 + Common Area Factor)
- Include corridors, restrooms, lobbies in common area calculation

**IBC Chapter 10 — Egress:**
- Occupant load factor: 100 gross SF (9.3 m²) per person for business
- Egress width: 0.2" per occupant for stairways, 0.15" for other components
- Max travel distance: 300ft (91m) sprinklered business occupancy
- Two exits required when occupant load > 49

**ADA/ANSI A117.1:**
- All doors minimum 900mm clear width
- Corridors minimum 1500mm for wheelchair passing
- 5% of workstations accessible (knee clearance 685mm)
- Accessible restroom on every floor

**Core-to-Window Depth:**
- Optimal 12-15m (40-50ft) for natural light penetration
- Open workspaces within 7.5m of window for daylight
- Perimeter 4.5m zone = prime office space

---

## LAYOUT PRINCIPLES

1. Reception at main entrance — first zone visitors see
2. Open workspace centrally placed, largest area
3. Private cabins along perimeter (window access, within 4.5m of facade)
4. Conference/meeting rooms near reception for visitor access
5. Pantry and restrooms clustered together (plumbing), in common area
6. Server room interior, no windows, climate controlled, min 1000mm clearance around racks
7. Corridors connecting all zones — minimum 1500mm, straight runs preferred
8. Fire exits within 60m (sprinklered) travel distance from all zones
9. Electrical panel rooms: 36" (900mm) working clearance per NEC 110.26
10. Two exits per floor when occupant load > 49 people
