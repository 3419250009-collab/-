# Office Room Standards

All dimensions in millimeters (mm). Clearance: 150mm. Wall thickness: 150mm.

| Zone Name       | Min Width | Min Depth | Typical Size  | Notes                          |
|-----------------|-----------|-----------|---------------|--------------------------------|
| Reception       | 3000      | 3000      | 4000 × 4000   |                                |
| Open Workspace  | 6000      | 5000      | 8000 × 6000   | Largest zone                   |
| Private Cabin   | 3000      | 3000      | 3500 × 4000   | Perimeter, window access       |
| Manager Cabin   | 3500      | 4000      | 4500 × 5000   | Perimeter, window access       |
| Conference Room | 4000      | 5000      | 5000 × 6000   | Near reception                 |
| Meeting Room    | 3000      | 3000      | 3500 × 4000   |                                |
| Pantry          | 2500      | 2500      | 3000 × 3500   |                                |
| Server Room     | 2500      | 3000      | 3000 × 4000   | Interior, no windows           |
| Restroom        | 2000      | 2500      | 3000 × 3000   | Corridor buffer required       |
| Corridor        | 1500      | 1500      | 1800 wide     |                                |
| Break Area      | 3000      | 3000      | 4000 × 4000   |                                |
| Storage         | 2000      | 2000      | 2500 × 3000   |                                |
