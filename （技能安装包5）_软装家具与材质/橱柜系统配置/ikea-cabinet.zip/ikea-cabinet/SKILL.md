---
name: ikea-cabinet
description: IKEA METOD base and wall cabinets. Use when the user asks to add, remove, or modify kitchen cabinets. Emits ikea-cabinet instances backed by a procedurally generated GLB.
---

# IKEA METOD cabinets

Cabinets are GLB-backed. Before you emit an `ikea-cabinet` instance, call the
`generate_cabinet` tool with the dimensions and colours you want; it writes a
GLB server-side (idempotent — same params return the same slug) and returns
the model slug. Put that slug in the instance's `model` field.

## Workflow

1. Decide on `variant`, `width_mm`, `height_mm`, `depth_mm`, `door_color`,
   plus a door-pull style: `handle_type` ∈ `bar` / `knob` / `none`, and (when
   `knob`) a `handle_model` slug from the **Knobs** section below. Pick the
   handle to match the design: see "Choosing a handle" below. Optionally pick
   a `hinge_side` (`left` / `right` / `up`) — see "Hinge orientation" below;
   omit it for an abstract centred handle. For a built-in eye-level oven
   tower in a single tall column, also set `oven_slot: true` — see "Oven-slot
   tall housings" below. To replace the single hinged door with a stack of
   MAXIMERA drawers (or a single full-height pull-out column for narrow W200
   / W300 bases), pass `drawer_fronts` — see "Drawer fronts" below.
2. Call `generate_cabinet({ variant, width_mm, height_mm, depth_mm, door_color, handle_type, handle_model, hinge_side, oven_slot, drawer_fronts })`.
   The tool returns `{ "slug": "gen-metod-base-600x800x600-beige-..." }`.
3. Emit an `ikea-cabinet` instance with `model: <slug>` in the scene JSON.

## JSON shape (scene instance)

```json
{
  "id": "cab-1",
  "kind": "ikea-cabinet",
  "model": "gen-metod-base-600x800x600-beige-hexf2efe8",
  "position": [0, 80, 0],
  "rotation": [0, 0, 0]
}
```

## Fields

- `id` — unique string in the scene.
- `model` — slug returned by `generate_cabinet`. Do not invent slugs; always
  get them from the tool.
- `position` — `[x, y, z]` in millimetres. The cabinet's origin is its
  **bottom-centre**; +Z is the door face.
- `rotation` — `[rx, ry, rz]` in radians. Rotate around Y to face a different wall.

## generate_cabinet parameters

- `variant`: `"metod-base"` (floor-standing), `"metod-wall"` (wall-mounted), or
  `"metod-tall"` (full-height floor-standing — larder, oven or fridge housing).
- `width_mm`: base/wall widths are **200, 300, 400, 600, 800**. Tall widths
  are **400, 600, 800** only.
- `height_mm`: base frames are always **800**. Wall frames are **400, 600,
  800, or 1000**. Tall frames are **1400, 2000, or 2200**.
- `depth_mm`: base/tall frames **600** (or **370** shallow). Wall frames
  **370** only.
- `door_color`: a named colour (`beige`, `white`, `off-white`, `marble-white`,
  `oak`, `walnut`, `anthracite`, `dark-grey`, `black`) or a 6-digit hex like
  `"#d6c6a0"`.
- `carcass_color` (optional): defaults to a neutral off-white.
- `handle_type` (optional): `"bar"` (default — slim black bar; horizontal on
  base/wall, **vertical 300 mm pull on tall**), `"knob"` (embed an IKEA knob
  — pair with `handle_model`), or `"none"` (bare door, for handle-less
  push-to-open looks like VOXTORP). **Vertical handle position follows the
  METOD reachability convention and is chosen automatically from `variant`:**
  - **base** → handle near the **top of the door** (~720 mm from cabinet
    bottom), so a standing user reaches *down*.
  - **wall** → handle near the **bottom of the door**, so a standing user
    can reach *up* to it above the worktop.
  - **tall** → handle at **waist / worktop height (~900 mm above the
    cabinet bottom)**. A handle at the top of a 1400/2000/2200 mm tall
    door would be unreachable; the generator places the handle at waist
    height regardless of door height. Bar pulls also rotate 90° to a
    300 mm **vertical** orientation on tall cabinets — long vertical
    pulls (BILLSBRO 720, HÄRSLEV) are the IKEA convention for pantry /
    fridge / oven housings.
- `handle_model` (optional): IKEA knob slug from the Knobs section. Required
  when `handle_type === "knob"`; ignored otherwise.
- `hinge_side` (**required**): `"left"` / `"right"` / `"up"`. See "Hinge
  orientation" below. The viewer uses this to swing the door open on hover,
  so every cabinet must declare one — for drawer / pull-out columns where
  there is no real hinge, pick `"right"` as a stand-in and keep
  `handle_type: "bar"` so the centred bar handle still reads as a drawer
  pull rather than an offset door knob.
- `oven_slot` (optional, `metod-tall` only): `true` to split the door into
  a lower panel (cabinet bottom → world y=880) and an upper panel (world
  y=1485 → cabinet top), leaving a 600 mm wide oven-housing slot in the
  middle. Each panel gets its own handle (lower at the top of its segment,
  upper at the bottom — both right next to the oven for waist-height
  access). Pair with an `ikea-oven` instance positioned in front. Requires
  `variant: "metod-tall"`, `width_mm: 600`, and `height_mm` ≥ 2000.
  See "Oven-slot tall housings" below.
- `drawer_fronts` (optional, `metod-base` only): array of nominal drawer
  heights in mm, bottom to top, summing to `height_mm`. Replaces the single
  hinged door with a stack of MAXIMERA-style drawer panels and animates as a
  slide-forward on hover (no swing). **Multi-front stacks** (length ≥ 2) get
  a centred handle on every panel — a true MAXIMERA drawer pull. **A
  single-element array** (e.g. `[800]`) emits one full-height pull-out front
  — the right shape for the MAXIMERA vertical pull-out interior in W200/W300
  bases — with the handle placed at the **top** of the panel and sized like a
  base-cabinet door handle, so the front reads identically to the hinged-door
  cabinets adjacent to it. See "Drawer fronts" below. Cannot combine with
  `oven_slot`; `hinge_side` is ignored when set.

## Hinge orientation

Real METOD doors hinge in three ways. The `hinge_side` parameter records
which one, pins the handle to the matching position on the door, and lets
the viewer swing the door open on hover. It is required on every cabinet —
for non-hinged drawer / pull-out columns, see the note in the parameter
list above.

- `"left"` — **side-hinged on the left edge.** Door swings open to the
  right. The handle goes near the **right** (free) edge of the door.
- `"right"` — **side-hinged on the right edge.** Door swings open to the
  left. The handle goes near the **left** (free) edge.
- `"up"` — **lift-up door** (UTRUSTA horizontal hinge along the top edge).
  Door pivots upward. The handle goes **centred along the bottom** of the
  door, where the user pulls. **`metod-wall` only** — the generator rejects
  `"up"` on base or tall cabinets.

The vertical position (top vs. bottom of door) is still chosen by the
generator from `variant`: base and tall → top, wall → bottom. `hinge_side`
only controls the **horizontal** position (and, for `"up"`, forces the
handle to the bottom-centre regardless of variant).

### Choosing which side to hinge

- **Pair adjacent cabinets so the doors meet at the handles, not at the
  hinges.** Two side-by-side base cabinets typically open *outward from
  the seam between them*: the left cabinet hinges on its **left** edge
  (so its handle is on the right, near the seam), and the right cabinet
  hinges on its **right** edge (handle on the left, also near the seam).
  The two handles end up next to each other in the middle, which both
  looks intentional and gives the user a single grab-zone for either
  door.
- **Hinge a single cabinet on the side away from the user's main path.**
  An end-of-run cabinet at the end of a galley should hinge on its outer
  edge so the door opens *into* the kitchen, not into the doorway.
- **Hinge cabinets next to a corner on the corner-side edge.** A door that
  swings open into a corner collides with the wall; flip the hinge.
- **For wall cabinets above a worktop, lift-up (`"up"`) is the right
  choice for short / wide frames** — wall cabinets at H400 or H600 with
  width ≥ 600 mm are commonly lift-up because a side-hinged door at
  that aspect ratio swings out far and bumps the user. Tall, narrow wall
  frames (H800 / H1000, W ≤ 400) stay side-hinged.
- **Pantries / tall cabinets** (`metod-tall`) usually hinge on the side
  closest to the wall they back onto, but follow the same "open away
  from traffic" rule.

When in doubt for a side-hinged cabinet, hinge on the side that's closer
to the wall or the run's end, so the door opens into the open part of
the kitchen.

## Oven-slot tall housings

Real IKEA METOD eye-level oven housings are built one of two ways: as a
stack of three separate cabinets (base + oven + wall) sharing a column,
or as a **single tall cabinet with the door cut for an oven slot** —
storage above and below, oven in the middle, all inside one carcass.
This skill supports both.

The single-tall option is enabled by `oven_slot: true` on a `metod-tall`
cabinet. The generator splits the front into two separate door panels:

- **Lower door**: from the cabinet bottom up to the oven slot at world
  y=880 mm. With the cabinet placed at `position.y = 80` (toe-kick top),
  this is an 800 mm tall door — exactly like a base-cabinet door.
  Handle is mounted at the top of this segment (reach-down convention,
  same as a real base cabinet, ~720 mm above the cabinet bottom).
- **Oven slot**: from world y=880 to y=1475 (the 595 mm MATÄLSKARE oven
  height) plus a 10 mm vent gap to y=1485. No door here — the oven
  panel sits in front, replacing the door in that band. Pair this
  cabinet with an `ikea-oven` instance at `position.y = 880`.
- **Upper door**: from world y=1485 to the cabinet top. With H2000 the
  upper door is ~515 mm tall; with H2200, ~715 mm. Handle is mounted
  at the **bottom** of this segment (reach-up convention, same as a
  wall cabinet) so it sits right above the oven at waist-and-a-bit
  height — easy to grab from below.

Constraints (the generator rejects the combination otherwise):

- `variant` must be `metod-tall`.
- `width_mm` must be **600** — built-in ovens are 60 cm; an 800 or 400
  mm wide tall cabinet won't host one.
- `height_mm` must be **≥ 2000** — the oven slot ends at y=1485, so
  H1400 leaves no room for an upper door. Use H2000 or H2200.
- Cannot combine with `hinge_side: "up"` (lift-up doors are wall-only).

`hinge_side: "left"` or `"right"` is allowed and applies to both the
lower and upper doors (they're stacked on the same hinge edge in real
IKEA installs). Omit `hinge_side` for centred handles, which reads as
an abstract sketch — fine, but real housings always pick a side.

When to choose this single-tall housing vs. a base+wall stack:

- **Single tall (`oven_slot: true`)** is the cleaner default for an
  eye-level oven — one cabinet entry in the scene, one carcass behind
  the doors, and a continuous run of side panels from floor to ceiling.
  This is how most modern IKEA kitchen renderings show oven towers.
  The carcass back wraps continuously behind the oven slot, matching a
  real METOD UTRUSTA oven housing.
- **Base + wall pair** (see `ikea-oven` for the layout) is functionally
  equivalent and useful when you want the oven housing's lower portion
  to share a worktop with adjacent base cabinets — the lower base
  cabinet's top edge can coincide with the worktop. With `oven_slot`
  the worktop must terminate at the tall cabinet's side (rule 3 in
  `ikea-designer`), the same as any other tall cabinet.

Both produce three visible door panels (base / oven / wall), so the
*final image* looks the same. Pick by which is structurally cleaner for
the kitchen you're building.

## Drawer fronts

**A typical kitchen has more drawer bases than hinged-door bases** —
cutlery, utensils, cookware, pots, and pans all live in MAXIMERA drawers,
not on shelves behind a hinged door. Hinged-door bases are reserved for
the smaller share of the run (small appliances stash, recyclables bin,
occasional cookware). On a 4–6 cabinet base run expect roughly 3–4
drawer bases and only 1–2 hinged-door bases; a kitchen with zero drawer
bases (or with hinged doors outnumbering drawers) is a real-world bug.
The canonical default for each drawer base is `drawer_fronts: [200, 200, 400]`
— three mostly-symmetric drawers (cutlery / utensils / pots, bottom-to-top)
on a 600 mm base. See rule 8 in `ikea-designer` for placement and counts.

Real METOD base cabinets are often built as drawer stacks rather than
hinged-door storage — MAXIMERA full-extension soft-close drawers are the
default fitting whenever the base houses cutlery, cookware, pots, or any
heavy/frequently-grabbed contents. Pass `drawer_fronts` to render this:
the single hinged door is replaced by a stack of drawer panels, each with
its own centred handle, and the viewer animates each panel as a
**slide-forward** pull-out on hover (instead of swinging like a door).

The same parameter also covers the MAXIMERA **vertical pull-out** in
narrow W200/W300 bases — pass `drawer_fronts: [800]` and the generator
emits a single full-height front that slides as one column.

### Shape

`drawer_fronts: number[]` — array of nominal heights in mm, **bottom to
top**, that sums to `height_mm` (so 800 for any base cabinet). Each part
must be one of `{100, 200, 400, 600, 800}` — the canonical METOD front
heights in mm.

### Canonical stacks for an H800 base

| `drawer_fronts` | Reads as |
|---|---|
| `[800]` | Single full-height front. **For W200/W300:** vertical MAXIMERA pull-out column (top-anchored handle, sized like a door handle — see "Handles for drawer fronts"). For W400+: an unusual single-tall MAXIMERA drawer. |
| `[200, 200, 400]` | **Canonical default** — three mostly-symmetric drawers (cutlery / utensils / pots). Use this on every drawer base unless there's a reason to deviate. |
| `[400, 400]` | Two equal MAXIMERA drawers (medium / medium). |
| `[200, 600]` | Shallow cutlery drawer over a deep pots drawer. |
| `[100, 100, 200, 400]` | Four-drawer MAXIMERA stack (cutlery / utensil / cookware / pots) — only when the cook needs an explicit utensils drawer separate from cookware. Otherwise prefer the 3-drawer default. |
| `[100, 100, 600]` | Two shallow drawers over a deep pots drawer. |

Other partitions are valid as long as parts come from `{100, 200, 400,
600, 800}` and sum to 800.

### Constraints (the generator rejects otherwise)

- `variant` must be `metod-base`. Drawers on wall and tall cabinets are
  uncommon in real METOD and not supported here — use a hinged door for
  those.
- Σ(parts) must equal `height_mm`.
- Each part must be in `{100, 200, 400, 600, 800}`.
- Multi-front stacks (length ≥ 2) require `width_mm ∈ {400, 600, 800}`
  — MAXIMERA does not exist in W200/W300, so a real two-drawer W300 base
  is not buildable. Single-front pull-outs (`[800]`) are allowed at any
  width and are how W200/W300 bases should be emitted.
- Cannot combine with `oven_slot`.
- `hinge_side` is ignored: drawer fronts have no hinge and the handle is
  centred horizontally on every panel. The schema still requires you to
  pass one — `"right"` is a fine stand-in.

### Handles for drawer fronts

The handle layout splits by stack length:

- **Multi-front stacks** (length ≥ 2): each panel gets a handle centred on
  its vertical midpoint, sized like a real drawer pull (~70 % of the panel
  width for the default bar). This is the true MAXIMERA drawer look.
- **Single-front pull-outs** (`[800]`, used for W200/W300 narrow vertical
  columns): the handle goes at the **top** of the panel — same vertical
  position as a regular base-cabinet door handle — and is sized like a door
  handle (~45 % of panel width), not a wide drawer pull. The narrow
  pull-out reads as a normal cabinet door in the run, just animated as a
  slide instead of a swing.

Match the handle **style** (`handle_type` and `handle_model`) to the rest
of the kitchen — a vertical pull-out should carry the same knob or bar as
the adjacent hinged base cabinets, not a different model. Mixing styles in
the same run reads as a mistake.

Drawer fronts read most correctly with **bar pulls** or **cup handles**;
knobs are also fine but bar/cup is the more idiomatic METOD look on
drawers (see "Choosing a handle"):

- `eneryda-cup-black` — cup pulls are dedicated drawer hardware in any
  Shaker / English / cottage / nautical kitchen. Pair with framed-door
  series like BODBYN or STENSUND. Best on the lower / deeper drawers.
- `hamphult-handle-oak`, `hackas-handle-anthracite`,
  `kallroer-handle-stainless`, `klingstorp-handle-porcelain`,
  `borghamn-handle-black` — bar pulls suit any width drawer.
- `billsbro-handle-anthracite-720` — the 720 mm extra-long bar **only**
  on W800 drawers (rule of thumb: bar length ≤ ~70% of cabinet width).
  Looks absurd on W400/W600.
- Plain `handle_type: "bar"` — the default slim black bar widens to ~70%
  of panel width on drawer fronts (vs. ~45% on doors), reading correctly
  as a drawer pull rather than a door knob. Safe default.
- `handle_type: "none"` — push-to-open EXCEPTIONELL drawers, the modern
  handle-less look. Pair with VOXTORP-style minimalist door cabinets in
  the same run.

Keep the handle choice **consistent across the run** — mixing knobs on
doors with cup pulls on drawer fronts within the same kitchen reads as
intentional and is the traditional Shaker/Hamptons move; mixing two
different drawer-handle shapes within a single column reads as a mistake.

## METOD dimensional reference

The METOD grid is strict. Valid `(width, height, depth)` tuples:

| Frame type | Widths (mm) | Heights (mm) | Depths (mm) |
|---|---|---|---|
| Base (`metod-base`) | 200, 300, 400, 600, 800 | **800** (fixed) | 370 or 600 |
| Wall (`metod-wall`) | 200, 300, 400, 600, 800 | 400, 600, 800, 1000 | 370 |
| Tall (`metod-tall`) | 400, 600, 800 | 1400, 2000, 2200 | 370 or 600 |

Invariants (useful for sanity-checking placements):

- **Internal width/height/depth = nominal − 36 mm** (two 18 mm melamine side panels).
  A W600 cabinet has 564 mm internal width; a D600 has 580 mm internal depth.
- **Door/drawer front actual = nominal − 3 mm** on each axis, giving a 1.5 mm reveal
  on every edge. A nominal 600 × 800 door measures 597 × 797 mm.
- **Suspension rail adds 10 mm** behind every cabinet; the cabinet-front-to-wall
  distance is `depth_mm + 10`.
- Door thickness is **16 mm** for flat fronts (VEDDINGE, VOXTORP-style profiles
  excepted) and **19 mm** for framed series (BODBYN, STENSUND, LERHYTTAN, ENKÖPING).
  The generator uses a single 18 mm slab — cosmetic only.
- Carcass is 18 mm melamine on sides/top/bottom and a 3–5 mm HDF back.

## Door/drawer front partitions

Front heights on a single frame must sum to the frame's nominal height.
Valid parts (cm) are `{10, 20, 40, 60, 80, 100, 120, 140, 200}`.

For `metod-base` cabinets you can render any of the canonical drawer
stacks (`{80}`, `{40, 40}`, `{20, 60}`, `{20, 20, 40}`, `{10, 10, 20, 40}`,
etc.) by passing `drawer_fronts` (in mm) — see "Drawer fronts" above. The
generator emits one panel per part with its own slide-on-hover handle.

For wall and tall cabinets the generator still renders a single door
covering the full frame; multi-front partitions on those variants are
informational only and not currently supported.

## Interior fittings (informational)

A METOD frame is just a box; what goes inside it is chosen separately.
The generator does not draw interior fittings, but the *exterior* of a
cabinet (handle position, front shape, suggested width) is constrained by
what the cabinet is meant to hold. Common METOD interiors and how they
read from outside:

- **UTRUSTA shelves** — default interior. Adjustable melamine or tempered
  glass shelves (W400 / W600 / W800 × D370 / D600). The generator bakes
  them into every hinged-door cabinet automatically (roughly one shelf
  per 500 mm of interior height) so the open door reveals storage rather
  than an empty box. No emit-time action needed; they're skipped on
  drawer cabinets (MAXIMERA fills the cavity instead) and skipped from
  the oven slot itself on `oven_slot` housings.
- **MAXIMERA drawers** — drawer boxes in {low, medium, high} heights for
  W400 / W600 / W800 frames at D370 or D600. Visible from outside as a
  stack of drawer fronts (one front per drawer); see the partitions
  section above. Soft-close is built into the runners.
- **MAXIMERA pull-out interior fittings** — vertical pull-out frames for
  **narrow** base cabinets. Two sizes: 20 cm fitting (164 mm interior ×
  530 mm deep × 620 mm tall, max load 12 kg) for a W200 base; 30 cm
  fitting for a W300 base. Both **require D=600** (the 530 mm fitting
  depth won't fit a D370 shallow base). The single full-height door
  front *is* the drawer front — the user grabs the door's handle and
  pulls the entire vertical column out as one drawer, exposing internal
  wire shelves for spices / oils / bottles.
- **UTRUSTA pull-out work surface** and **under-sink organiser** —
  invisible from outside; not modelled.

### Narrow pull-out columns (MAXIMERA W200 / W300)

W200 and W300 base cabinets in real METOD kitchens are almost always
MAXIMERA pull-outs, not hinged-door cabinets — a 200 or 300 mm hinged
door is too narrow to be useful, and the pull-out fitting is what these
widths exist for. Treat any W200 / W300 `metod-base` you emit as a
pull-out column.

The right way to emit one is `drawer_fronts: [800]` — a single full-height
drawer-front. This produces one panel with a **top-anchored handle sized
like a base-cabinet door handle**, so it reads identically to the hinged
single-door narrow bases adjacent to it, but the viewer animates it as a
**slide-forward** pull-out on hover (matching the way the MAXIMERA
vertical pull-out interior actually moves: the whole column of internal
wire shelves slides out as one drawer). Pick the same `handle_type` /
`handle_model` you used for the surrounding hinged cabinets so the run
reads as one consistent set. See "Drawer fronts" below.

- **Use D=600 only** — the MAXIMERA fitting is 530 mm deep. A W200/W300
  on a D=370 shallow base has no real-world interior to match, so prefer
  D=600 even if the rest of the run is shallow.
- `hinge_side` is ignored once `drawer_fronts` is set; the schema still
  requires you to pass one — `"right"` is fine as a stand-in.

## Hinge mechanics (exterior aspects)

`hinge_side` covers *which edge* the door pivots on. Real METOD hinges
also differ in opening angle, soft-close, and push-to-open behaviour.
Most of those are invisible from outside the closed cabinet, but two map
onto emit-time choices:

- **Soft-close** (UTRUSTA hinge with built-in damper) is the modern
  METOD default. Visible only as smooth, slow door closing — no
  geometric difference. Assume every cabinet has it; nothing to emit.
- **Push-to-open / handle-less** (UTRUSTA push-opener for side or
  horizontal doors) lets the door open when pressed rather than pulled,
  so the cabinet has **no handle**. Emit `handle_type: "none"`. This is
  the canonical choice for VOXTORP-style minimalist / handle-less
  kitchens, and it pairs with any `hinge_side` (`"left"`, `"right"`, or
  `"up"`). Don't mix push-to-open cabinets with knobbed cabinets in the
  same run — push-to-open is a whole-kitchen design choice.
- **Opening angle** (95° / 110° / 153°) is invisible from outside the
  closed cabinet. Real installs use 153° for end-of-run cabinets that
  need to clear a perpendicular wall, but the planner doesn't model
  swing collisions, so no emit-time action is needed.
- **Lift-up horizontal hinge** is already exposed via `hinge_side:
  "up"` (UTRUSTA horizontal hinge with damper). Combine with
  `handle_type: "none"` for a push-to-open lift-up door (UTRUSTA hinge
  with push-opener for horizontal doors).

## Knobs (door pulls)

When `handle_type === "knob"`, the cabinet generator embeds an IKEA knob
model into the door at the standard METOD mounting position (top of door
for base/tall, bottom of door for wall cabinets). Always pick a knob whose
finish complements the door colour and the kitchen's overall mood.

Available knob/handle slugs (a deliberately *wide* catalogue — round knobs,
long pull bars, cup handles, porcelain, wood, brass, stainless, painted
plastic. The silhouettes and materials are dramatically different, so pick
by *shape* and *material* first, then by finish):

- `bagganaes-knob-black` — BAGGANÄS knob, **Ø21 × 24 mm**, matte black.
  Modern minimalist silhouette: a perfectly straight cylinder with crisp
  edges, no taper, no decoration. Powder-coated steel, low-sheen black
  finish that reads as solid and graphic against light doors. Good for
  contemporary, Scandinavian, monochrome, or industrial kitchens; pairs
  well with white, off-white, marble-white, oak, light-grey doors and with
  matte-black plumbing fixtures. Avoid on already-dark doors (anthracite,
  black) where it disappears.
- `eneryda-knob-brass` — ENERYDA knob, **Ø20 × 21 mm**, polished brass.
  Traditional silhouette with a softly rounded, subtly tapered profile —
  classical without being ornate. Brass-coloured nickel-plated metal with a
  warm yellow lustre. Best for warm, classic, transitional, or
  farmhouse-style kitchens; pairs especially well with off-white, beige,
  marble-white, sage / muted greens, and walnut doors. Avoid mixing with
  cool-toned chrome or stainless fixtures elsewhere in the room.
- `gubbarp-knob-white` — GUBBARP knob, **Ø20 × 27 mm**, white plastic.
  Stubby cylindrical knob, friendly almost cartoonish silhouette. Matte
  white plastic with a slight off-white warmth, completely flat finish (no
  metallic sheen). Reads as cheerful and budget-Scandinavian; the natural
  pick for kid-friendly, playful, or pure-white kitchens. Pairs with
  off-white, marble-white, beige, light-grey doors. Avoid on dark doors and
  in any kitchen aiming for sophistication or weight.
- `vinnaeset-knob-beech` — VINNÄSET knob, **Ø37 × ~22 mm**, solid beech wood.
  A larger-than-typical round wooden knob with a clean, slightly domed
  profile. Visible pale beech grain, satin natural finish, no stain. Reads
  as Japandi / Scandinavian-natural / mid-century-warm. Pairs with white,
  off-white, oak, walnut, sage doors and with any kitchen leaning into
  natural materials. Avoid on dark or formal kitchens — the bare wood
  reads as casual, not refined.
- `klingstorp-knob-porcelain` — KLINGSTORP knob, **Ø30 × ~30 mm**,
  off-white porcelain-look ceramic with a chrome-plated metal collar.
  Traditional flared / slightly mushroom-shaped silhouette — wider at the
  top for easy gripping. Smooth glossy ceramic finish with a single bright
  chrome ring. Reads as classic, English-country, vintage-traditional,
  cottage. Pairs with marble-white BODBYN, off-white, beige, sage doors.
  Avoid in modern, industrial, or monochrome schemes.
- `kalerum-knob-stainless` — KALERUM knob, **Ø30 × ~28 mm**, brushed
  stainless steel. A medium round knob with a slightly domed top and a
  satin sweep finish — cooler-toned, more substantial, and more
  professional-looking than the brass ENERYDA. Reads as modern-Scandinavian,
  contemporary, transitional. Pairs with white, marble-white, anthracite,
  dark-grey, oak, walnut doors and with stainless or chrome plumbing.
  Avoid alongside warm brass fixtures (clashes).
- `hamphult-handle-oak` — HAMPHULT pull, **146 × 30 × 18 mm**, natural oak
  wood. A long horizontal *bar handle* (not a knob) with softly rounded
  ends, mounted with two screws. Visible oak grain, warm honey tone, matte
  satin finish. Reads as Japandi / warm-modern; the right choice when the
  door is also wood (pairs especially with oak or walnut doors) or when the
  kitchen leans into natural materials. Avoid on cool-grey or anthracite
  doors where the wood looks orphaned.
- `hackas-handle-anthracite` — HACKÅS pull, **100 × 18 × 24 mm**,
  anthracite (dark charcoal) painted aluminium. A short, slim rectangular
  bar handle with a slight D-profile so the front face catches highlights.
  Industrial / utilitarian silhouette, low-sheen near-black finish. Good
  for industrial-loft, dark-and-moody, or contrast-on-light kitchens; pairs
  with white, light-grey, sage, navy, and oak doors. Avoid on already-dark
  anthracite/black doors where it vanishes.
- `borghamn-handle-black` — BORGHAMN pull, **170 × ~12 × ~28 mm**,
  hand-forged textured iron. A long horizontal bar with a visibly knobbly,
  hammered surface — *not* extruded; the iron looks weighty, slightly
  irregular, hand-made. Matte black, rough finish that absorbs light.
  Reads as rustic / farmhouse / cottage / industrial-with-craft. Pairs
  with marble-white BODBYN, sage, off-white, oak, walnut doors. Avoid in
  slick contemporary or minimalist kitchens — the texture fights flat
  modern fronts.
- `klingstorp-handle-porcelain` — KLINGSTORP pull, **141 × ~22 × ~28 mm**,
  off-white porcelain shaft on chrome-plated metal ends. A long bar pull
  with two visible bright chrome screw bosses bracketing a creamy glossy
  ceramic centre — strongly traditional / vintage / Edwardian-kitchen
  character. Pairs with marble-white BODBYN, off-white, beige, sage doors;
  excellent on framed-door series (BODBYN, STENSUND). Avoid in modern,
  industrial, or monochrome kitchens.
- `kallroer-handle-stainless` — KALLRÖR pull, **213 × ~12 × ~30 mm**,
  polished stainless steel tube. Long thin straight bar with a perfectly
  cylindrical cross-section and a bright mirror finish — the "professional
  kitchen" look. Reads as modern-stainless, industrial-clean, contemporary.
  Pairs with white, marble-white, anthracite, dark-grey, black doors and
  with stainless appliances or chrome plumbing. Avoid in warm-traditional
  kitchens (the chrome shine fights wood and brass).
- `billsbro-handle-anthracite-720` — BILLSBRO pull, **720 × ~12 × ~30 mm**,
  anthracite (dark charcoal) painted aluminium. An *extra-long* slim
  minimalist bar that nearly spans a full drawer or door front. Reads as
  modern-minimalist / contemporary / large-scale-luxury. **Use only on
  wide drawers (W≥800 mm) or full-height pantry doors (`metod-tall`)**;
  looks absurd on a 200/300/400 mm cabinet (the bar is wider than the
  door). Pairs with white, off-white, marble-white, anthracite, oak,
  walnut doors. Avoid on small cabinets and on framed-door series.
- `eneryda-cup-black` — ENERYDA cup handle, **89 × ~25 × ~25 mm**, matte
  black powder-coated metal. A *cup pull* — half-moon scoop you fit
  fingers under from below; this is dedicated drawer hardware in any
  Shaker / English / nautical kitchen. Strongly traditional / Shaker /
  cottage. Pairs with marble-white BODBYN, sage, navy, off-white doors.
  **Use on what reads as a drawer front** (small base cabinet, low frame);
  on a tall door it looks misplaced. Avoid in modern / industrial /
  Scandinavian-flat-front kitchens.
- `begripa-handle-blue` — BEGRIPA pull, **130 × ~30 × ~30 mm**, soft
  light-blue moulded plastic, half-round (D-profile) silhouette with
  rounded ends. Designed for IKEA's SMÅSTAD kids' storage, so a pure
  pastel-blue colour with a smooth matte finish. Reads as playful,
  kid's-room, family-kitchen, primary-colour-pop. Pairs with white,
  marble-white, oak doors when the design is explicitly child-friendly.
  Avoid in adult / sophisticated / monochrome kitchens.
- `dragsmark-handle-grey-green` — DRAGSMARK clip-on, **40 × ~20 × ~30 mm**,
  soft grey-green moulded plastic. A small chunky clip-on with a flat
  front face — the only no-drill option here, so reads as
  renter-friendly / temporary / refresh-without-commitment. Distinctive
  sage / grey-green colour with a smooth matte finish. Reads as
  playful-modern, eclectic, rental-refresh, colour-pop accent. Pairs with
  white, off-white, marble-white, light-grey doors when adding a small
  pop of colour. Avoid in formal or fully-monochrome kitchens.

## Choosing a handle

Match the handle to the design intent, not just the door colour:

- **Bar (`handle_type: "bar"`)** — the default. A neutral choice for
  fast-moving design iterations or when the user hasn't named a style. It
  reads as generic-modern and won't fight a strong door colour.
- **Knob (`handle_type: "knob"`)** — pick when the design has a clear
  stylistic direction. The slug name is `handle_model`; round knobs, bar
  pulls, and cup handles all use the same field. Map by *design intent*
  first, then refine by warm/cool finish:
  - Contemporary / Scandinavian / monochrome → `bagganaes-knob-black`.
  - Modern-stainless / pro-kitchen / contemporary-cool → `kalerum-knob-stainless`
    (round knob) or `kallroer-handle-stainless` (long polished tube).
  - Traditional / classical / transitional / warm-Scandinavian / farmhouse-brass
    → `eneryda-knob-brass`.
  - Vintage / English-country / Edwardian / cottage-with-ceramic
    → `klingstorp-knob-porcelain` (small) or `klingstorp-handle-porcelain`
    (long bar). Use both consistently within one kitchen.
  - Rustic / farmhouse-with-craft / forged / hand-made aesthetic
    → `borghamn-handle-black` (textured iron bar).
  - Shaker / nautical / Hamptons / drawer-led traditional → `eneryda-cup-black`.
    Cup pulls are drawer hardware — pair with framed-door series like
    BODBYN or STENSUND, and only on small/short cabinets that read as
    drawer fronts.
  - Japandi / warm-modern / wood-on-wood → `hamphult-handle-oak` (long
    oak bar) or `vinnaeset-knob-beech` (round wood knob). Use the bar on
    drawer-shaped fronts, the knob on door-shaped ones.
  - Industrial-loft / dark-moody / utilitarian → `hackas-handle-anthracite`
    (short anthracite bar).
  - Modern-minimalist / large-scale luxury / drawer-led contemporary
    → `billsbro-handle-anthracite-720`. **Only on wide drawers (W≥800)
    or `metod-tall` pantry doors** — the bar is 720 mm long and looks
    absurd on smaller fronts.
  - Playful / budget-Scandinavian / kid-friendly / all-white →
    `gubbarp-knob-white`.
  - Kid's room / family kitchen / colour-pop primary → `begripa-handle-blue`.
  - Renter-refresh / no-drill / colour-pop accent → `dragsmark-handle-grey-green`.
  - Match warm finishes (brass, oak/beech wood, marble-white, porcelain)
    to ENERYDA brass / VINNÄSET beech / KLINGSTORP porcelain / HAMPHULT
    oak; match cool finishes (matte-black, stainless, chrome, anthracite,
    white, light-grey) to BAGGANÄS black / KALERUM stainless / KALLRÖR
    stainless / HACKÅS / BILLSBRO anthracite. Don't mix warm-knob with
    cool-tap or vice versa.
  - Bar-style pulls (HAMPHULT, HACKÅS, KALLRÖR, BILLSBRO, BORGHAMN,
    KLINGSTORP handle) and cup pulls (ENERYDA cup) on **drawer fronts**
    specifically look more correct than knobs; on door fronts either is
    fine, though long bars (KALLRÖR 213 mm, BILLSBRO 720 mm) need a wide
    enough door not to look comical (rule of thumb: bar length ≤ ~70% of
    cabinet width).
- **None (`handle_type: "none"`)** — handle-less doors. Choose for
  push-to-open VOXTORP-style minimalist designs, or where the user
  explicitly asks for a clean, hardware-free look.

Keep the handle choice **consistent across a single kitchen run** — mixing
knob shapes within one cabinet column reads as a mistake. It's fine to
contrast base-cabinet knobs with wall-cabinet knobs only when there's a
deliberate design reason (e.g. dark base + brass uppers); otherwise stick
with one knob across all cabinets.

## Door series (cosmetic mapping)

The generator takes a colour, not a series name, but common METOD door series
map to these palette choices:

- `off-white` / `white` → VEDDINGE, RINGHULT (flat modern).
- `marble-white` → BODBYN, STENSUND (framed traditional).
- `beige` → HAVSTORP beige, BODBYN off-white.
- `oak` → ASKERSUND, FRÖJERED (wood-effect).
- `walnut` → SINARP, VOXTORP walnut.
- `anthracite` / `dark-grey` → LERHYTTAN grey, NICKEBO anthracite.
- `black` → KUNGSBACKA, VOXTORP dark grey.

## Placement rules

- For `metod-base`: set `y = constants.toeKickH` (standard 80 mm) so the
  cabinet bottom rests on the toe-kick top. The cabinet height is 800 mm.
  Worktop top lands at `80 + 800 + thickness` (≈908 or 918 mm for 28 or 38
  mm slabs) — this is the standard working height.
- For `metod-wall`: set `y` to the wall-cabinet mount height. **1400 mm** puts
  the cabinet bottom 500 mm above an 918 mm worktop — the METOD-recommended
  minimum clearance. Typical column heights (base rail ↔ wall rail):
  1200 / 1400 / 1600 mm giving total kitchen heights of 2080 / 2280 / 2480 mm.
- For `metod-tall`: set `y = constants.toeKickH` (80 mm) — tall cabinets stand
  on the same legs as base cabinets. A tall cabinet replaces the base+wall
  pair in its column; **do not place a worktop in front of it** and **do not
  place a wall cabinet above it** unless the total stack still fits under the
  ceiling. Total height from floor to cabinet top: 80 + {1400, 2000, 2200}
  = 1480 / 2080 / 2280 mm. The generator renders a single full-height door;
  real METOD H2000/H2200 frames split into two doors (typically 1200 + 800 or
  1400 + 800) — this is cosmetic only and doesn't affect placement.
- Cabinets are laid side-by-side along X. Two 600-wide cabinets at x=0 and
  x=600 are adjacent with no gap.
- The cabinet's back is at `z = -depth/2`; its front is at `z = +depth/2`.
- **All cabinets on the same wall must share the same back-face Z.** Pick
  one wall plane `z_wall` for the run and back every cabinet — base, wall,
  and tall — onto it. Because base/tall depth (600) ≠ wall depth (370),
  this means **wall cabinets need a non-zero `position.z`**: a wall
  cabinet's `position.z = base_position.z - (base_depth - wall_depth) / 2`.
  Worked: base at `position.z = 0` with `depth_mm = 600` → its back is at
  `z = -300`. A 370-deep wall cabinet on the same wall must sit at
  `position.z = -300 + 370/2 = -115` so its back also lands at `z = -300`.
  Forgetting this is what makes wall cabinets visibly float forward away
  from the wall while the base cabinets sit flush.
- The wall plane itself is `z_wall - 10` (10 mm suspension-rail gap); leave
  that gap free behind wall cabinets. Tall cabinets (depth 600) align with
  the bases and need no Z offset relative to them.

## Worked example

User: "Show me a 600 base cabinet with a beige havstorp-style door and brass knobs."

```
generate_cabinet({
  "variant": "metod-base",
  "width_mm": 600,
  "height_mm": 800,
  "depth_mm": 600,
  "door_color": "beige",
  "handle_type": "knob",
  "handle_model": "eneryda-knob-brass",
  "hinge_side": "left"
})
→ { "slug": "gen-metod-base-600x800x600-beige-hexf2efe8-hinge-left-h-eneryda-knob-brass" }
```

Scene instance:

```json
{
  "id": "cab-1",
  "kind": "ikea-cabinet",
  "model": "gen-metod-base-600x800x600-beige-hexf2efe8-hinge-left-h-eneryda-knob-brass",
  "position": [0, 80, 0],
  "rotation": [0, 0, 0]
}
```

`hinge_side: "left"` puts the brass knob near the right (free) edge of the
door at the top — a single right-of-centre cabinet that opens to the right.
Pair this with a mirror cabinet at `x = 600` using `hinge_side: "right"` to
get two doors that meet at their handles in the middle.
